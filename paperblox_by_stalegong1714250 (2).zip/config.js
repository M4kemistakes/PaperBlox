export const config = {
    inventory: {
        slots: 10,
        height: 64,
        background: '#1a1a1a',
        slotColor: '#333333',
        spacing: 4
    },
    game: {
        backgroundColor: 0x87ceeb,
        groundColor: 0x3c8f3c,
        character: {
            moveSpeed: 5,
            turnSpeed: 2
        },
        combat: {
            swordDamage: 15,
            maxHealth: 100,
            swingCooldown: 500, // milliseconds
            hitRange: 2.5, // units
            swordScale: {
                x: 0.5,
                y: 1.5
            }
        }
    },
    chat: {
        maxMessages: 50,
        fadeDelay: 5000, // Time in ms before chat messages start to fade
        maxMessageLength: 100
    },
    leaderboard: {
        refreshRate: 5000, // How often to update leaderboard in ms
        maxEntries: 10, // Maximum number of entries to show
        background: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        textColor: '#fff',
        borderColor: '#fff'
    },
    multiplayer: {
        maxPlayers: 16,
        respawnTime: 3000, // Time in ms before respawning
        spawnRadius: 20, // Random spawn radius from center
        hitboxSize: 1.5 // Size of player hitbox for collision detection
    }
};