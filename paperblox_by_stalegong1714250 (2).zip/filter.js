export class ChatFilter {
    constructor() {
        this.bannedWords = [
            // Expanded list of inappropriate content
            'alcohol', 'anarchy', 'arrest', 'assault', 'abuse',
            'ban', 'battlefield', 'beat', 'beer', 'berserk', 'bite', 'blood', 'blow', 'bomb', 'bone', 'burn',
            'bullet', 'bully', 'butcher', 'butt',
            'chase', 'cheat', 'choke', 'cigarette', 'combat', 'conspiracy', 'corpse', 'corrupt', 'crack', 'crash',
            'crazy', 'crime', 'criminal', 'crush', 'cult', 'curse',
            'dagger', 'danger', 'dead', 'death', 'demon', 'destroy', 'devil', 'die', 'disease', 'disgust', 'disturb',
            'dope', 'dragon', 'drown', 'drug', 'drunk',
            'enemy', 'evil', 'execute', 'explode',
            'fail', 'fatal', 'fear', 'fight', 'fire', 'fist', 'force', 'fraud',
            'gang', 'gun', 'gore', 'grave', 'greed',
            'hack', 'hammer', 'hang', 'harm', 'hate', 'hell', 'hit', 'horror', 'hostile', 'hunt', 'hurt',
            'illegal', 'immoral', 'infect', 'inject', 'insane', 'insult',
            'jail', 'jealous', 'jerk',
            'kidnap', 'kill', 'knife',
            'lie', 'lonely', 'lose', 'loser', 'loud', 'lurk',
            'mad', 'malice', 'mean', 'menace', 'metal', 'militant', 'murder', 'mutant', 'mutilate',
            'naughty', 'negative', 'noob', 'nuke',
            'obey', 'obscene', 'obsess', 'offend',
            'pain', 'panic', 'parasite', 'pest', 'pig', 'pistol', 'plague', 'poison', 'poor', 'prison', 'profane',
            'punch', 'punish', 'push',
            'quarrel', 'quit',
            'rabid', 'rage', 'raid', 'rebel', 'reckless', 'revenge', 'rifle', 'riot', 'risk', 'rob', 'rude', 'rush',
            'sad', 'savage', 'scare', 'scream', 'seize', 'serious', 'severe', 'shady', 'shake', 'sharp', 'shock',
            'shoot', 'shove', 'shred', 'sick', 'sin', 'siren', 'skull', 'slash', 'slave', 'slay', 'smack', 'smash',
            'smite', 'smoke', 'snap', 'snatch', 'sneak', 'snipe', 'soldier', 'spear', 'spook', 'stab', 'steal',
            'sting', 'stink', 'strangle', 'strike', 'stupid', 'suffer',
            'tank', 'taunt', 'terror', 'threat', 'throw', 'torture', 'toxic', 'trap', 'trash', 'trauma', 'trigger',
            'trouble', 'ugly', 'unfair', 'unholy', 'unlucky', 'violent', 'venom', 'vermin', 'vicious', 'victim',
            'vile', 'villain', 'violate', 'virus', 'voodoo', 'vulgar',
            'war', 'waste', 'weapon', 'weird', 'whack', 'wicked', 'wild', 'wound', 'wreck', 'wrong',
            'yell', 'zero', 'zombie',

            // Common hate speech and offensive terms
            'bigot', 'discrimination', 'hate', 'hatred', 'nazi', 'racist', 'supremacy', 'terrorism',

            // Additional profanity variations
            'fck', 'fuk', 'fvck', 'fcuk', 'phuck', 'phuk', 'fuq', 'fux',
            'sht', 'sh1t', 'shiit', 'shyt',
            'dmn', 'dman', 'dam',
            'btch', 'b1tch', 'bytch',
            'fk', 'fx', 'fck',
            'sx', 'sxx', 'secks',
            'prn', 'pr0n', 'pron',
            'dik', 'd1k', 'dck',

            // Contact info patterns
            'discord', 'skype', 'snapchat', 'whatsapp', 'facebook', 'instagram', 'twitter',
            'email', 'gmail', 'yahoo', 'hotmail', 'phone', 'number', 'contact', 'dm', 'pm',
            'http', 'https', 'www', '.com', '.net', '.org', '.ru', '.io',

            // Common bypass attempts
            'address', 'age', 'bypass', 'connect', 'contact', 'dating', 'friend', 'follow',
            'gender', 'insta', 'link', 'meet', 'message', 'private', 'profile', 'social',
            'snap', 'tag', 'text', 'twitter', 'user',

            // Additional safety terms
            'adult', 'alone', 'bedroom', 'camera', 'child', 'cute', 'date', 'girl', 'guy',
            'kiss', 'love', 'massage', 'meet', 'private', 'secret', 'teen', 'touch', 'young',

            // Numbers and common substitutions
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '$', '@', '!', '#', '%', '^', '&', '*', '(', ')', '_', '+', '=',

            // Personal info terms
            'password', 'credit', 'card', 'bank', 'account', 'address', 'location', 'school',
            'live', 'real', 'name', 'age', 'phone', 'social', 'security', 'birth', 'day',
            
            // Gaming terms often used negatively
            'exploit', 'glitch', 'hack', 'spam', 'troll', 'grief', 'report', 'ban', 'kick',
            'mod', 'admin', 'developer', 'dev', 'owner', 'staff', 'team',

            // Common toxic gaming phrases
            'ez', 'easy', 'noob', 'newb', 'trash', 'garbage', 'bad', 'worst', 'suck',
            'uninstall', 'quit', 'delete', 'leave', 'cry', 'mad', 'salt', 'salty',
            
            // Additional phrases
            'inappropriate', 'offensive', 'report', 'moderator', 'admin', 'banned',
            'warning', 'account', 'terminate', 'deleted', 'removed', 'violation',
            
            // Common bypassing techniques
            'vv', 'vv/', '\\/\\/', 'vv/vv', '/\\', '\\'
        ];
        
        // Common substitutions 
        this.substitutions = {
            'a': ['4', '@', 'α', 'д', '/\\', '^', 'а', 'æ', 'å', 'ą', 'α', 'ά', 'ą', 'ẫ', 'ă'],
            'b': ['6', '8', 'в', '|3', 'ь', 'β', 'б', 'þ', 'ß', 'в'],
            'c': ['(', '[', '{', '<', '¢', '©', 'с', 'ç', 'ć', 'č'],
            'd': ['|)', 'в', 'д', 'ð', 'đ', 'ď', 'δ', 'ð'],
            'e': ['3', '€', 'є', 'е', '&', 'э', 'ε', 'έ', 'è', 'é', 'ê', 'ë', 'ę', 'ė'],
            'f': ['ƒ', 'φ', '|=', 'ф', 'ƒ'],
            'g': ['6', '9', 'б', 'г', 'ģ', 'ğ', 'ǥ', 'ġ'],
            'h': ['|-|', '#', 'н', 'ħ', 'ĥ', 'ή', 'ђ'],
            'i': ['1', '!', '|', 'і', '/', '\\', 'l', 'ї', 'ί', 'ι', 'ï', 'ī', 'į'],
            'j': ['ј', 'ĵ', 'ј'],
            'k': ['|<', 'к', 'ķ', 'ĸ', 'қ'],
            'l': ['1', '|', 'і', 'ł', 'ļ', 'ĺ', 'ľ'],
            'm': ['м', '|v|', 'м', 'м', 'ļ', 'ṃ'],
            'n': ['и', 'п', '/\\/', 'ń', 'ņ', 'ň', 'ή'],
            'o': ['0', 'о', 'ο', '()', '[]', 'ø', 'ő', 'ô', 'ö', 'ò', 'ó', 'ō', 'õ'],
            'p': ['|о', 'п', 'р', 'ρ', 'þ', 'р'],
            'q': ['q', 'ο', 'σ', 'ø'],
            'r': ['я', '®', 'г', 'ŕ', 'ř', 'ŗ'],
            's': ['$', '5', 'ѕ', 'z', 'ś', 'š', 'ş', 'ŝ'],
            't': ['7', '+', 'т', 'ţ', 'ť', 'ț'],
            'u': ['μ', 'υ', 'ц', 'ü', 'ų', 'ů', 'ű', 'ύ'],
            'v': ['\\/', '√', 'ν', 'υ'],
            'w': ['vv', '\\/\\/', 'ш', 'ẃ', 'ẅ', 'ŵ'],
            'x': ['×', 'х', '><', 'χ'],
            'y': ['ч', 'у', '¥', 'ý', 'ÿ', 'ŷ'],
            'z': ['2', 'ʒ', 'ž', 'ź', 'ż', 'ζ']
        };
    }

    normalize(text) {
        let normalized = text.toLowerCase();
        
        // Remove whitespace
        normalized = normalized.replace(/\s+/g, '');
        
        // Remove non-alphanumeric characters
        normalized = normalized.replace(/[^a-z0-9]/g, '');
        
        // Replace substitutions
        for (const [letter, substitutes] of Object.entries(this.substitutions)) {
            for (const sub of substitutes) {
                const escapedSub = sub.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                normalized = normalized.replace(new RegExp(escapedSub, 'g'), letter);
            }
        }
        
        // Collapse repeated letters
        normalized = normalized.replace(/(.)\1+/g, '$1');
        
        return normalized;
    }

    containsBannedWord(text) {
        const normalized = this.normalize(text);
        
        // Check entire message
        if (this.bannedWords.some(word => normalized.includes(word))) {
            return true;
        }
        
        // Check each word individually 
        const words = normalized.split(/\s+/);
        return words.some(word => 
            this.bannedWords.some(banned => 
                word.includes(banned) || 
                banned.includes(word) ||
                this.levenshteinDistance(word, banned) <= 1
            )
        );
    }

    // Helper function to catch near-matches
    levenshteinDistance(a, b) {
        if (a.length === 0) return b.length;
        if (b.length === 0) return a.length;

        const matrix = [];

        for (let i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }

        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }

        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }

        return matrix[b.length][a.length];
    }

    filter(text) {
        if (this.containsBannedWord(text)) {
            return '*** Message filtered ***';
        }
        return text;
    }
}