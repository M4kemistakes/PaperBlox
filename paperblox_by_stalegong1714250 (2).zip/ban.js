export class BanManager {
    constructor(gameOverlay, guiPanel, room) {
        this.bannedUsers = new Set();
        this.protectedUsers = new Set(['stalegong1714250']);
        this.room = room;
        this.initBanUI(gameOverlay, guiPanel);
    }

    initBanUI(gameOverlay, guiPanel) {
        // Create ban button
        const banButton = document.createElement('button');
        banButton.className = 'ban-button';
        banButton.innerHTML = `
            <img src="Ban_Hammer.webp" alt="Ban Hammer">
            <span>Ban</span>
        `;
        guiPanel.appendChild(banButton);

        // Create ban panel
        const banPanel = document.createElement('div');
        banPanel.className = 'ban-panel';
        banPanel.innerHTML = `
            <h2>Ban Player</h2>
            <input type="text" class="ban-input" placeholder="Enter username to ban">
            <div class="ban-buttons">
                <button class="ban-confirm">Ban Player</button>
                <button class="ban-cancel">Cancel</button>
            </div>
        `;
        document.body.appendChild(banPanel);

        banButton.addEventListener('click', () => {
            banPanel.classList.add('active');
        });

        const banInput = banPanel.querySelector('.ban-input');
        const banConfirm = banPanel.querySelector('.ban-confirm');
        const banCancel = banPanel.querySelector('.ban-cancel');

        banConfirm.addEventListener('click', () => {
            const usernameToBan = banInput.value.trim();
            if (usernameToBan && !this.protectedUsers.has(usernameToBan)) {
                this.bannedUsers.add(usernameToBan);
                this.room.send({
                    type: "ban",
                    username: usernameToBan
                });
                banInput.value = '';
                banPanel.classList.remove('active');
            } else if (this.protectedUsers.has(usernameToBan)) {
                alert('This user cannot be banned.');
                banInput.value = '';
            }
        });

        banCancel.addEventListener('click', () => {
            banInput.value = '';
            banPanel.classList.remove('active');
        });
    }

    isBanned(username) {
        return this.bannedUsers.has(username);
    }
}

