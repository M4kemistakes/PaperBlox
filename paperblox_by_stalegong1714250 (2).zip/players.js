import * as THREE from 'three';
import { config } from './config.js';
import { SoundManager } from './sound.js';

export class PlayerManager {
    constructor(scene, room) {
        this.scene = scene;
        this.room = room;
        this.players = new Map();
        this.soundManager = new SoundManager();
        this.initPresenceSync();
        this.initPresenceUpdateRequests();
    }

    createPlayerModel() {
        const character = new THREE.Group();
        
        // Body (Torso)
        const body = new THREE.Mesh(
            new THREE.BoxGeometry(1, 1.4, 0.6),
            new THREE.MeshPhongMaterial({ color: 0x0066ff }) // Blue torso
        );
        body.position.y = 1.1;
        character.add(body);
        
        // Add P logo to torso
        const logoTexture = new THREE.TextureLoader().load('P-3-20-2025.png');
        const logoGeometry = new THREE.PlaneGeometry(0.4, 0.4);
        const logoMaterial = new THREE.MeshBasicMaterial({
            map: logoTexture,
            transparent: true,
            side: THREE.DoubleSide
        });
        const logo = new THREE.Mesh(logoGeometry, logoMaterial);
        logo.position.set(0, 1.2, 0.31);
        logo.rotation.y = 0;
        character.add(logo);
        
        // Head (larger and more blocky)
        const head = new THREE.Mesh(
            new THREE.BoxGeometry(1, 1, 1),
            new THREE.MeshPhongMaterial({ color: 0xffcc00 }) // Yellow head
        );
        head.position.y = 2.3;
        character.add(head);

        // Face (simple smile)
        const faceGeometry = new THREE.PlaneGeometry(0.6, 0.6);
        const faceCanvas = document.createElement('canvas');
        const ctx = faceCanvas.getContext('2d');
        faceCanvas.width = 128;
        faceCanvas.height = 128;
        ctx.fillStyle = 'black';
        // Draw eyes
        ctx.fillRect(30, 40, 20, 20);
        ctx.fillRect(78, 40, 20, 20);
        // Draw smile
        ctx.beginPath();
        ctx.arc(64, 80, 30, 0, Math.PI);
        ctx.lineWidth = 8;
        ctx.stroke();
        
        const faceTexture = new THREE.CanvasTexture(faceCanvas);
        const faceMaterial = new THREE.MeshBasicMaterial({
            map: faceTexture,
            transparent: true
        });
        const face = new THREE.Mesh(faceGeometry, faceMaterial);
        face.position.set(0, 2.3, 0.51);
        character.add(face);
        
        // Arms (blocky)
        const armGeometry = new THREE.BoxGeometry(0.5, 1.4, 0.5);
        const armMaterial = new THREE.MeshPhongMaterial({ color: 0x0066ff }); // Blue arms
        
        const leftArm = new THREE.Mesh(armGeometry, armMaterial);
        leftArm.position.set(-0.75, 1.4, 0);
        character.add(leftArm);
        
        const rightArm = new THREE.Mesh(armGeometry, armMaterial);
        rightArm.position.set(0.75, 1.4, 0);
        character.add(rightArm);
        
        // Legs (blocky)
        const legGeometry = new THREE.BoxGeometry(0.5, 1.4, 0.5);
        const legMaterial = new THREE.MeshPhongMaterial({ color: 0x336600 }); // Green legs
        
        const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
        leftLeg.position.set(-0.3, 0.7, 0);
        character.add(leftLeg);
        
        const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
        rightLeg.position.set(0.3, 0.7, 0);
        character.add(rightLeg);

        // Add sword
        const swordTexture = new THREE.TextureLoader().load('Regular_sword.webp');
        const swordGeometry = new THREE.PlaneGeometry(0.5, 1.5);
        const swordMaterial = new THREE.MeshBasicMaterial({
            map: swordTexture,
            transparent: true,
            side: THREE.DoubleSide
        });
        
        const sword = new THREE.Mesh(swordGeometry, swordMaterial);
        sword.position.set(0.8, 1.2, 0);
        sword.rotation.z = Math.PI / 4;
        sword.rotation.y = Math.PI / 2;
        sword.isSword = true;
        character.add(sword);

        // Add username label
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = 256;
        canvas.height = 64;
        context.font = '24px Comic Sans MS';
        context.fillStyle = 'white';
        context.textAlign = 'center';
        
        const texture = new THREE.CanvasTexture(canvas);
        const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
        const sprite = new THREE.Sprite(spriteMaterial);
        sprite.position.y = 3;
        sprite.scale.set(2, 0.5, 1);
        character.add(sprite);
        character.nameSprite = sprite;

        return character;
    }

    updatePlayerUsername(player, username) {
        const canvas = player.nameSprite.material.map.image;
        const context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.font = '24px Comic Sans MS';
        context.fillStyle = 'white';
        context.textAlign = 'center';
        context.fillText('@' + username, canvas.width / 2, canvas.height / 2);
        player.nameSprite.material.map.needsUpdate = true;
    }

    initPresenceSync() {
        this.room.subscribePresence((presence) => {
            for (const clientId in presence) {
                if (clientId === this.room.party.client.id) continue;

                const playerData = presence[clientId];
                if (!playerData) continue;

                if (!this.players.has(clientId)) {
                    // Create new player
                    const player = this.createPlayerModel();
                    this.scene.add(player);
                    this.players.set(clientId, player);
                    
                    // Set username from peer data
                    if (this.room.party.peers[clientId]) {
                        this.updatePlayerUsername(player, this.room.party.peers[clientId].username);
                    }
                }

                // Update player position and rotation
                const player = this.players.get(clientId);
                if (playerData.position) {
                    player.position.set(
                        playerData.position.x,
                        playerData.position.y,
                        playerData.position.z
                    );
                }
                if (playerData.rotation) {
                    player.rotation.y = playerData.rotation;
                }

                // Handle combat state
                if (playerData.health <= 0 && !player.isDead) {
                    player.isDead = true;
                    this.soundManager.playDeathSound();
                } else if (playerData.health > 0) {
                    player.isDead = false;
                }

                // Handle sword swing animation
                if (playerData.isSwinging && !player.isSwinging) {
                    player.isSwinging = true;
                    const sword = player.children.find(child => child.isSword);
                    if (sword) {
                        const initialRotation = sword.rotation.z;
                        new TWEEN.Tween({ rotation: initialRotation })
                            .to({ rotation: initialRotation + Math.PI * 1.5 }, 300)
                            .easing(TWEEN.Easing.Cubic.Out)
                            .onUpdate(function(obj) {
                                sword.rotation.z = obj.rotation;
                            })
                            .onComplete(function() {
                                player.isSwinging = false;
                            })
                            .start();
                    }
                }
            }

            // Remove disconnected players
            for (const [clientId, player] of this.players) {
                if (!presence[clientId]) {
                    this.scene.remove(player);
                    this.players.delete(clientId);
                }
            }
        });
    }

    handleSwordCollision(attacker, target) {
        const distance = attacker.position.distanceTo(target.position);
        if (distance <= config.game.combat.hitRange) {
            return true;
        }
        return false;
    }

    requestDamage(targetClientId, damage) {
        this.room.requestPresenceUpdate(targetClientId, {
            type: 'damage',
            amount: damage
        });
    }

    initPresenceUpdateRequests() {
        this.room.subscribePresenceUpdateRequests((request, fromClientId) => {
            if (request.type === 'damage') {
                const currentHealth = this.room.presence[this.room.clientId].health || config.game.combat.maxHealth;
                const newHealth = Math.max(0, currentHealth - request.amount);
                
                this.room.updatePresence({
                    health: newHealth
                });

                if (newHealth <= 0) {
                    this.soundManager.playDeathSound();
                    // Increment killer's score
                    const killerPresence = this.room.presence[fromClientId];
                    if (killerPresence) {
                        this.room.requestPresenceUpdate(fromClientId, {
                            type: 'incrementKills'
                        });
                    }
                }
            } else if (request.type === 'incrementKills') {
                const currentKills = this.room.presence[this.room.clientId].kills || 0;
                this.room.updatePresence({
                    kills: currentKills + 1
                });
            }
        });
    }

    updateLocalPlayerPosition(character) {
        this.room.party.updatePresence({
            position: {
                x: character.position.x,
                y: character.position.y,
                z: character.position.z
            },
            rotation: character.rotation.y
        });
    }

    playerDied() {
        this.soundManager.playDeathSound();
    }
}