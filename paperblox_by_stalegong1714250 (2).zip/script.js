import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { config } from './config.js';
import { Leaderboard } from './leaderboard.js';
import { PlayerManager } from './players.js';
import { ChatFilter } from './filter.js';
import { BanManager } from './ban.js';

// Initialize WebsimSocket room at the global scope
const room = new WebsimSocket();
let isConnected = true;

let isAdmin = false;
const ADMIN_USERNAME = 'stalegong1714250';

// Combat code moved to PlayerManager to handle death sounds

document.addEventListener('DOMContentLoaded', async function() {
    // Check if current user is admin
    const user = await window.websim.getUser();
    isAdmin = user && user.username === ADMIN_USERNAME;

    const menuButton = document.getElementById('menuButton');
    const guiPanel = document.querySelector('.gui-panel');
    const homeButton = document.getElementById('homeButton');
    const playButton = document.getElementById('playButton');
    
    menuButton.addEventListener('click', function() {
        guiPanel.classList.toggle('active');
    });

    homeButton.addEventListener('click', function() {
        window.location.reload();
    });
    
    // Add click handler for game card
    const gameCard = document.querySelector('.game-card');
    gameCard.addEventListener('click', function() {
        // You can add game launch functionality here
        console.log('Game clicked!');
    });

    // Create game overlay
    const gameOverlay = document.createElement('div');
    gameOverlay.className = 'game-overlay';
    document.body.appendChild(gameOverlay);

    // Create canvas for the game
    const canvas = document.createElement('canvas');
    canvas.id = 'gameCanvas';
    gameOverlay.appendChild(canvas);

    // Create inventory bar
    const inventoryBar = document.createElement('div');
    inventoryBar.className = 'inventory-bar';
    gameOverlay.appendChild(inventoryBar);

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'close-game';
    closeButton.textContent = 'Close Game';
    gameOverlay.appendChild(closeButton);

    const leaveButton = document.createElement('button');
    leaveButton.className = 'leave-button';
    leaveButton.innerHTML = '<img src="icon_leave.png" alt="Leave">';
    gameOverlay.appendChild(leaveButton);

    leaveButton.addEventListener('click', function() {
        window.location.reload();
    });

    // Setup inventory slots
    for (let i = 0; i < config.inventory.slots; i++) {
        const slot = document.createElement('div');
        slot.className = 'inventory-slot';
        slot.textContent = i;
        inventoryBar.appendChild(slot);
    }

    let scene, camera, renderer, controls;
    let character, mixer, animations = {};
    let moveForward = false, moveBackward = false, moveLeft = false, moveRight = false;
    const velocity = new THREE.Vector3();
    const direction = new THREE.Vector3();
    const clock = new THREE.Clock();

    let health = config.game.combat.maxHealth;
    let lastSwing = 0;
    let isSwinging = false;
    let sword;
    let healthBar;
    let kills = 0;

    function createHealthBar() {
        healthBar = document.createElement('div');
        healthBar.className = 'health-bar';
        const healthFill = document.createElement('div');
        healthFill.className = 'health-fill';
        healthBar.appendChild(healthFill);
        gameOverlay.appendChild(healthBar);
        updateHealthBar();
    }

    function updateHealthBar() {
        const healthFill = healthBar.querySelector('.health-fill');
        const percentage = (health / config.game.combat.maxHealth) * 100;
        healthFill.style.width = `${percentage}%`;
    }

    function createSword() {
        // Load the sword model
        const loader = new GLTFLoader();
        let swordTexture = new THREE.TextureLoader().load('Regular_sword.webp');
        
        // Create a plane geometry for the sword
        const swordGeometry = new THREE.PlaneGeometry(0.5, 1.5);
        const swordMaterial = new THREE.MeshBasicMaterial({
            map: swordTexture,
            transparent: true,
            side: THREE.DoubleSide
        });
        
        sword = new THREE.Mesh(swordGeometry, swordMaterial);
        
        // Position the sword relative to the character's right hand
        sword.position.set(0.8, 1.2, 0);
        sword.rotation.z = Math.PI / 4;
        sword.rotation.y = Math.PI / 2; // Make sword face sideways
        
        sword.visible = false;
    }

    function swingSword() {
        if (!sword.visible || isSwinging) return;
        
        const now = Date.now();
        if (now - lastSwing < config.game.combat.swingCooldown) return;
        
        isSwinging = true;
        lastSwing = now;
        
        const initialRotation = sword.rotation.z;
        new TWEEN.Tween({ rotation: initialRotation })
            .to({ rotation: initialRotation + Math.PI * 1.5 }, 300) // Increased swing arc and duration
            .easing(TWEEN.Easing.Cubic.Out) // Smoother easing
            .onUpdate(function(obj) {
                sword.rotation.z = obj.rotation;
            })
            .onComplete(function() {
                isSwinging = false;
                sword.rotation.z = initialRotation;
                // Here you would check for hits on other players
            })
            .start();
    }

    function initGame() {
        scene = new THREE.Scene();
        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        
        // Add controls
        controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.minDistance = 5;
        controls.maxDistance = 15;
        controls.maxPolarAngle = Math.PI / 2;

        // Create ground
        const groundGeometry = new THREE.PlaneGeometry(100, 100);
        const groundMaterial = new THREE.MeshPhongMaterial({ color: config.game.groundColor });
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        scene.add(ground);

        // Add lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);
        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(5, 5, 5);
        directionalLight.castShadow = true;
        scene.add(directionalLight);

        // Initialize PlayerManager
        const playerManager = new PlayerManager(scene, room);
        character = playerManager.createPlayerModel();
        scene.add(character);

        createSword();
        createHealthBar();
        
        // Add the first sword to inventory
        const firstSlot = document.querySelector('.inventory-slot');
        firstSlot.innerHTML = `
            <div class="inventory-item sword">
                <div class="item-icon">⚔️</div>
            </div>
        `;
        firstSlot.classList.add('selected');
        sword.visible = true;

        character.add(sword);

        // Position camera
        camera.position.set(0, 5, 10);
        camera.lookAt(character.position);

        // Set background color
        scene.background = new THREE.Color(config.game.backgroundColor);

        // Add keyboard controls
        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('keyup', onKeyUp);
    }

    function onKeyDown(event) {
        if (!isConnected) return;
        switch(event.code) {
            case 'KeyW': moveForward = true; break;
            case 'KeyS': moveBackward = true; break;
            case 'KeyA': moveLeft = true; break;
            case 'KeyD': moveRight = true; break;
            case 'Space': swingSword(); break;
        }
    }

    function onKeyUp(event) {
        if (!isConnected) return;
        switch(event.code) {
            case 'KeyW': moveForward = false; break;
            case 'KeyS': moveBackward = false; break;
            case 'KeyA': moveLeft = false; break;
            case 'KeyD': moveRight = false; break;
        }
    }

    function updateCharacter() {
        const delta = clock.getDelta();
        
        direction.z = Number(moveForward) - Number(moveBackward);
        direction.x = Number(moveRight) - Number(moveLeft);
        direction.normalize();

        if (moveForward || moveBackward || moveLeft || moveRight) {
            velocity.z = direction.z * 5;
            velocity.x = direction.x * 5;
            
            character.position.x += velocity.x * delta;
            character.position.z += velocity.z * delta;
            
            if (direction.z !== 0 || direction.x !== 0) {
                const angle = Math.atan2(direction.x, direction.z);
                character.rotation.y = angle;
            }

            // Sync position with other players
            const playerManager = new PlayerManager(scene, room);
            playerManager.updateLocalPlayerPosition(character);
        }

        // Update camera to follow character
        const idealOffset = new THREE.Vector3(-0, 5, -10);
        idealOffset.applyQuaternion(character.quaternion);
        idealOffset.add(character.position);
        
        const idealLookat = new THREE.Vector3(0, 0, 0);
        idealLookat.add(character.position);
        
        controls.target.copy(character.position);
    }

    function animate() {
        requestAnimationFrame(animate);
        if (character) {
            updateCharacter();
        }
        TWEEN.update();
        controls.update();
        renderer.render(scene, camera);
    }

    function handleResize() {
        if (camera && renderer) {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
    }

    // Create connection overlay
    const connectionOverlay = document.createElement('div');
    connectionOverlay.className = 'connection-overlay';
    connectionOverlay.innerHTML = `
        <img src="no connection@3x.png" alt="Connection Lost" class="connection-image">
        <div class="connection-message">Connection Lost<br>Please check your internet connection</div>
    `;
    document.body.appendChild(connectionOverlay);

    // Monitor connection status
    room.onclose = () => {
        isConnected = false;
        connectionOverlay.classList.add('active');
        // Disable game controls
        if (character) {
            moveForward = moveBackward = moveLeft = moveRight = false;
        }
    };

    room.onopen = () => {
        isConnected = true;
        connectionOverlay.classList.remove('active');
    };

    // Add chat system elements
    const chatButton = document.createElement('button');
    chatButton.className = 'chat-button';
    chatButton.innerHTML = '<img src="icon_chat.png" alt="Chat">';
    gameOverlay.appendChild(chatButton);

    const chatContainer = document.createElement('div');
    chatContainer.className = 'chat-container';
    gameOverlay.appendChild(chatContainer);

    const chatMessages = document.createElement('div');
    chatMessages.className = 'chat-messages';
    chatContainer.appendChild(chatMessages);

    const chatInput = document.createElement('input');
    chatInput.type = 'text';
    chatInput.className = 'chat-input';
    chatInput.maxLength = config.chat.maxMessageLength;
    chatInput.placeholder = 'Press Enter to chat...';
    chatContainer.appendChild(chatInput);

    const chatFilter = new ChatFilter();

    let isChatOpen = false;
    let username = 'Player'; // Default username

    // Get websim username when game starts
    async function initializeUsername() {
        try {
            const user = await window.websim.getUser();
            if (user && user.username) {
                username = user.username;
            }
        } catch (error) {
            console.error('Error getting username:', error);
        }
    }

    chatButton.addEventListener('click', () => {
        isChatOpen = !isChatOpen;
        chatContainer.classList.toggle('active');
        if (isChatOpen) {
            chatInput.focus();
        }
    });

    function addChatMessage(message, sender) {
        // Filter the message
        const filteredMessage = chatFilter.filter(message);
        
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message';
        messageElement.innerHTML = `<span class="sender">@${sender}:</span> ${filteredMessage}`;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Remove old messages if exceeding max
        while (chatMessages.children.length > config.chat.maxMessages) {
            chatMessages.removeChild(chatMessages.firstChild);
        }

        // Fade out message after delay
        setTimeout(() => {
            messageElement.classList.add('fading');
        }, config.chat.fadeDelay);

        // Send message to other players
        room.send({
            type: "chat",
            message: filteredMessage,
            sender: sender
        });
    }

    chatInput.addEventListener('keypress', (e) => {
        if (!isConnected) return;
        if (e.key === 'Enter' && chatInput.value.trim()) {
            const message = chatInput.value.trim();
            if (chatFilter.containsBannedWord(message)) {
                alert('Please keep chat appropriate!');
            } else {
                addChatMessage(message, username);
            }
            chatInput.value = '';
        }
    });

    // Prevent game controls when typing
    chatInput.addEventListener('keydown', (e) => {
        e.stopPropagation();
    });

    // Handle incoming chat messages
    room.onmessage = (event) => {
        const data = event.data;
        if (data.type === "chat") {
            addChatMessage(data.message, data.sender);
        }
        // Handle ban events
        if (data.type === "ban") {
            const bannedUsers = new Set();
            bannedUsers.add(data.username);
        }
    };

    function updateHealth(newHealth) {
        const wasDead = health <= 0;
        health = newHealth;
        updateHealthBar();
        room.party.updatePresence({
            health: health
        });
        
        // Play death sound if player just died
        if (!wasDead && health <= 0) {
            const playerManager = new PlayerManager(scene, room);
            playerManager.playerDied();
        }
    }

    function incrementKills() {
        kills++;
        room.party.updatePresence({
            kills: kills
        });
    }

    // Update the presence when joining
    room.party.updatePresence({
        health: config.game.combat.maxHealth,
        kills: 0
    });

    if (isAdmin) {
        const banManager = new BanManager(gameOverlay, guiPanel, room);

        // Check if user is banned before starting game
        playButton.addEventListener('click', async function(e) {
            const user = await window.websim.getUser();
            if (banManager.isBanned(user.username)) {
                e.preventDefault();
                alert('You have been banned from this game.');
                return;
            }
            // ... rest of existing playButton click handler ...
            if (!isConnected) {
                return; // Don't start game if disconnected
            }
            gameOverlay.classList.add('active');
            await initializeUsername(); 
            if (!renderer) {
                initGame();
                const leaderboard = new Leaderboard(gameOverlay, room);
                animate();
                window.addEventListener('resize', handleResize);
            }
        });
    } else {
        playButton.addEventListener('click', async function() {
            if (!isConnected) {
                return; // Don't start game if disconnected
            }
            gameOverlay.classList.add('active');
            await initializeUsername(); 
            if (!renderer) {
                initGame();
                const leaderboard = new Leaderboard(gameOverlay, room);
                animate();
                window.addEventListener('resize', handleResize);
            }
        });
    }

    closeButton.addEventListener('click', function() {
        gameOverlay.classList.remove('active');
    });
});