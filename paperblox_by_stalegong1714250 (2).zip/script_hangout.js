import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { config } from './config.js';
import { Leaderboard } from './leaderboard.js';
import { PlayerManager } from './players.js';
import { ChatFilter } from './filter.js';

// Initialize WebsimSocket room at the global scope
const room = new WebsimSocket();
let isConnected = true;

document.addEventListener('DOMContentLoaded', async function() {
    const playButton2 = document.getElementById('playButton2');
    const gameOverlay = document.createElement('div');
    gameOverlay.className = 'game-overlay';
    document.body.appendChild(gameOverlay);

    // Create canvas for the game
    const canvas = document.createElement('canvas');
    canvas.id = 'gameCanvas';
    gameOverlay.appendChild(canvas);

    const leaveButton = document.createElement('button');
    leaveButton.className = 'leave-button';
    leaveButton.innerHTML = '<img src="icon_leave.png" alt="Leave">';
    gameOverlay.appendChild(leaveButton);

    leaveButton.addEventListener('click', function() {
        window.location.reload();
    });

    let scene, camera, renderer, controls;
    let character;
    let moveForward = false, moveBackward = false, moveLeft = false, moveRight = false;
    const velocity = new THREE.Vector3();
    const direction = new THREE.Vector3();
    const clock = new THREE.Clock();

    const chatFilter = new ChatFilter();
    let username = 'Player';

    function createTree(x, z) {
        const tree = new THREE.Group();

        // Create trunk
        const trunkGeometry = new THREE.CylinderGeometry(0.3, 0.4, 2, 8);
        const trunkMaterial = new THREE.MeshPhongMaterial({ color: 0x4d2926 });
        const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
        trunk.position.y = 1;
        tree.add(trunk);

        // Create leaves
        const leavesGeometry = new THREE.ConeGeometry(1.5, 3, 8);
        const leavesMaterial = new THREE.MeshPhongMaterial({ color: 0x0d5c0d });
        const leaves = new THREE.Mesh(leavesGeometry, leavesMaterial);
        leaves.position.y = 3.5;
        tree.add(leaves);

        tree.position.set(x, 0, z);
        return tree;
    }

    function initGame() {
        scene = new THREE.Scene();
        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        
        // Add controls
        controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.minDistance = 5;
        controls.maxDistance = 15;
        controls.maxPolarAngle = Math.PI / 2;

        // Create ground
        const groundGeometry = new THREE.PlaneGeometry(100, 100);
        const groundMaterial = new THREE.MeshPhongMaterial({ color: config.game.groundColor });
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        scene.add(ground);

        // Add trees
        for (let i = 0; i < 20; i++) {
            const x = (Math.random() - 0.5) * 80;
            const z = (Math.random() - 0.5) * 80;
            const tree = createTree(x, z);
            scene.add(tree);
        }

        // Add lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);
        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(5, 5, 5);
        directionalLight.castShadow = true;
        scene.add(directionalLight);

        // Initialize PlayerManager
        const playerManager = new PlayerManager(scene, room);
        character = playerManager.createPlayerModel();
        scene.add(character);

        // Position camera
        camera.position.set(0, 5, 10);
        camera.lookAt(character.position);

        // Set background color
        scene.background = new THREE.Color(config.game.backgroundColor);

        // Add keyboard controls
        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('keyup', onKeyUp);
    }

    function onKeyDown(event) {
        if (!isConnected) return;
        switch(event.code) {
            case 'KeyW': moveForward = true; break;
            case 'KeyS': moveBackward = true; break;
            case 'KeyA': moveLeft = true; break;
            case 'KeyD': moveRight = true; break;
        }
    }

    function onKeyUp(event) {
        if (!isConnected) return;
        switch(event.code) {
            case 'KeyW': moveForward = false; break;
            case 'KeyS': moveBackward = false; break;
            case 'KeyA': moveLeft = false; break;
            case 'KeyD': moveRight = false; break;
        }
    }

    function updateCharacter() {
        const delta = clock.getDelta();
        
        direction.z = Number(moveForward) - Number(moveBackward);
        direction.x = Number(moveRight) - Number(moveLeft);
        direction.normalize();

        if (moveForward || moveBackward || moveLeft || moveRight) {
            velocity.z = direction.z * 5;
            velocity.x = direction.x * 5;
            
            character.position.x += velocity.x * delta;
            character.position.z += velocity.z * delta;
            
            if (direction.z !== 0 || direction.x !== 0) {
                const angle = Math.atan2(direction.x, direction.z);
                character.rotation.y = angle;
            }

            // Sync position with other players
            const playerManager = new PlayerManager(scene, room);
            playerManager.updateLocalPlayerPosition(character);
        }

        // Update camera to follow character
        const idealOffset = new THREE.Vector3(-0, 5, -10);
        idealOffset.applyQuaternion(character.quaternion);
        idealOffset.add(character.position);
        
        const idealLookat = new THREE.Vector3(0, 0, 0);
        idealLookat.add(character.position);
        
        controls.target.copy(character.position);
    }

    function animate() {
        requestAnimationFrame(animate);
        if (character) {
            updateCharacter();
        }
        controls.update();
        renderer.render(scene, camera);
    }

    function handleResize() {
        if (camera && renderer) {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
    }

    // Add chat system elements
    const chatButton = document.createElement('button');
    chatButton.className = 'chat-button';
    chatButton.innerHTML = '<img src="icon_chat.png" alt="Chat">';
    gameOverlay.appendChild(chatButton);

    const chatContainer = document.createElement('div');
    chatContainer.className = 'chat-container';
    gameOverlay.appendChild(chatContainer);

    const chatMessages = document.createElement('div');
    chatMessages.className = 'chat-messages';
    chatContainer.appendChild(chatMessages);

    const chatInput = document.createElement('input');
    chatInput.type = 'text';
    chatInput.className = 'chat-input';
    chatInput.maxLength = config.chat.maxMessageLength;
    chatInput.placeholder = 'Press Enter to chat...';
    chatContainer.appendChild(chatInput);

    let isChatOpen = false;

    // Get websim username when game starts
    async function initializeUsername() {
        try {
            const user = await window.websim.getUser();
            if (user && user.username) {
                username = user.username;
            }
        } catch (error) {
            console.error('Error getting username:', error);
        }
    }

    chatButton.addEventListener('click', () => {
        isChatOpen = !isChatOpen;
        chatContainer.classList.toggle('active');
        if (isChatOpen) {
            chatInput.focus();
        }
    });

    function addChatMessage(message, sender) {
        // Filter the message
        const filteredMessage = chatFilter.filter(message);
        
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message';
        messageElement.innerHTML = `<span class="sender">@${sender}:</span> ${filteredMessage}`;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        while (chatMessages.children.length > config.chat.maxMessages) {
            chatMessages.removeChild(chatMessages.firstChild);
        }

        setTimeout(() => {
            messageElement.classList.add('fading');
        }, config.chat.fadeDelay);

        room.send({
            type: "chat",
            message: filteredMessage,
            sender: sender
        });
    }

    chatInput.addEventListener('keypress', (e) => {
        if (!isConnected) return;
        if (e.key === 'Enter' && chatInput.value.trim()) {
            const message = chatInput.value.trim();
            if (chatFilter.containsBannedWord(message)) {
                alert('Please keep chat appropriate!');
            } else {
                addChatMessage(message, username);
            }
            chatInput.value = '';
        }
    });

    // Prevent game controls when typing
    chatInput.addEventListener('keydown', (e) => {
        e.stopPropagation();
    });

    // Handle incoming chat messages
    room.onmessage = (event) => {
        const data = event.data;
        if (data.type === "chat") {
            addChatMessage(data.message, data.sender);
        }
    };

    // Monitor connection status
    room.onclose = () => {
        isConnected = false;
        document.querySelector('.connection-overlay').classList.add('active');
        if (character) {
            moveForward = moveBackward = moveLeft = moveRight = false;
        }
    };

    room.onopen = () => {
        isConnected = true;
        document.querySelector('.connection-overlay').classList.remove('active');
    };

    playButton2.addEventListener('click', async function() {
        if (!isConnected) return;
        gameOverlay.classList.add('active');
        if (!renderer) {
            initGame();
            await initializeUsername();
            const leaderboard = new Leaderboard(gameOverlay, room);
            animate();
            window.addEventListener('resize', handleResize);
        }
    });
});