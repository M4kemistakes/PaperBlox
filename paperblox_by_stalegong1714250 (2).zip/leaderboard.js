import { config } from './config.js';

export class Leaderboard {
    constructor(gameOverlay, room) {
        this.gameOverlay = gameOverlay;
        this.room = room;
        this.button = null;
        this.panel = null;
        this.init();
    }

    init() {
        // Create leaderboard button
        this.button = document.createElement('button');
        this.button.className = 'leaderboard-button';
        this.button.innerHTML = '<img src="icon_leaderboard.png" alt="Leaderboard">';
        this.gameOverlay.appendChild(this.button);

        // Create leaderboard panel
        this.panel = document.createElement('div');
        this.panel.className = 'leaderboard-panel';
        this.panel.innerHTML = `
            <h2>Leaderboard</h2>
            <div class="leaderboard-entries"></div>
        `;
        this.gameOverlay.appendChild(this.panel);

        // Toggle leaderboard visibility
        this.button.addEventListener('click', () => {
            this.panel.classList.toggle('active');
        });

        // Start periodic updates
        this.startUpdates();
    }

    startUpdates() {
        // Initial update
        this.update();

        // Subscribe to presence changes
        this.room.party.subscribePresence(() => {
            this.update();
        });

        // Periodic updates
        setInterval(() => this.update(), config.leaderboard.refreshRate);
    }

    update() {
        const entries = this.panel.querySelector('.leaderboard-entries');
        if (!entries) return;

        entries.innerHTML = ''; // Clear current entries

        // Get all connected players
        const players = [];
        for (const clientId in this.room.party.peers) {
            const peer = this.room.party.peers[clientId];
            const presence = this.room.party.presence[clientId] || {};
            players.push({
                username: peer.username,
                health: presence.health || config.game.combat.maxHealth,
                kills: presence.kills || 0
            });
        }

        // Add current player
        const currentPresence = this.room.party.presence[this.room.party.client.id] || {};
        players.push({
            username: this.room.party.client.username,
            health: currentPresence.health || config.game.combat.maxHealth,
            kills: currentPresence.kills || 0
        });

        // Sort players by kills
        players.sort((a, b) => b.kills - a.kills);

        // Create leaderboard entries
        players.slice(0, config.leaderboard.maxEntries).forEach((player, index) => {
            const entry = document.createElement('div');
            entry.className = 'leaderboard-entry';
            entry.style.fontFamily = 'Comic Sans MS, cursive';  
            entry.innerHTML = `
                <span class="rank">#${index + 1}</span>
                <span class="username">@${player.username}</span>
                <span class="stats">
                    <span class="kills">Kills: ${player.kills}</span>
                    <span class="health">HP: ${player.health}</span>
                </span>
            `;
            entries.appendChild(entry);
        });
    }
}