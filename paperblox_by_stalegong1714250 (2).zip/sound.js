export class SoundManager {
    constructor() {
        this.deathSound = new Audio('ouch.ogg');
    }

    playDeathSound() {
        this.deathSound.currentTime = 0; // Reset sound to start
        this.deathSound.play();
    }
}

